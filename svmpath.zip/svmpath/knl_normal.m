function K = knl_normal(x, y, sigma)
%function K = knl_normal(x, y, sigma)
%   normalized radial basis (Gaussian) kernel
%   x       n x p feature vector
%   y       m x p feature vector
%   sigma   kernel width
%   K       n x m kernel matrix
%
if nargin < 2, y = x; end
if nargin < 3, sigma = 1; end

normx = normsqr(x);
normy = normsqr(y);
[X1 Y1] = ndgrid(normx, normy);
K = exp(-(X1 - 2*x*y' + Y1) / (2*sigma^2)) / (sqrt(2*pi)*sigma)^size(x,2);

function y = normsqr(x)
%function y = normsqr(x)
%   compute norm squres of each row of xx
%   x      n x p feature vector
%   y      n x 1 norm squres
%
y = sum(x.^2,2);
