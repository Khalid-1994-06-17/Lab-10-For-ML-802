%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function plot_cssvm(x, y, hkernel, kernelparam, lambda, alpha, alpha0, bfile, filepath)
% function plot_cssvm(x, y, hkernel, kernelparam, lambda, alpha, alpha0, bfile, filepath)
%	x				N x p feature vector
%	y				N x 1 label
%	hkernel			kernel function handle
%	kernelparam		kernel parameter
%	lambda			lambda=1/C
%	alpha			solution path - normal vector
%	alpha0			solution path - intercept
%
if nargin<8, bfile=false; end
if nargin<9, filepath='pics\'; end

[N M] = size(alpha);

if (length(lambda)<M)
    lambda=lambda*ones(M,1);
end
if (nargin< 7 || length(alpha0)<M)
    alpha0=zeros(M,1);
end

x = x(:,1:2);

blinear = isequal(hkernel, @knl_poly) && (kernelparam(1) == 1);

if (blinear)	Kgrid = []; X1 = []; X2 = [];
else			[Kgrid X1 X2]= util_knlgrid(x, hkernel, kernelparam);
end

plot_init();
for l=1:M
	fhat = plot_cssvm_fgrid(x, y, Kgrid, lambda(l), alpha(:,l), alpha0(l), blinear);
    filename = [filepath num2str(l, '%03d')];
    plot_cssvm_step(x, y, X1, X2, fhat, blinear, bfile, filename);
end
