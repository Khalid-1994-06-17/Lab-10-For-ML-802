function [x y] = util_rdbenchdata(strset,stridx,type,class)
% function x = util_rdbenchdata(strset,stridx,type,class)
%	strset		dataset name
%	stridx		dataset index
%	type		dataset type 'train' or 'test'
%	class		label
% 
%	read benchmark dataset and return negative class data points
% 
if nargin<3, type='train'; end
if nargin<4, class=0; end

filepath = ['./' strset '_'];
filename = [filepath stridx '.mat'];
fid = fopen(filename);
if (fid>0)
    fclose(fid);
    dataset = load(filename, type);
    data = dataset.(type).data;
    labels = dataset.(type).labels;
else
    strdata   = [filepath type '_data_'   stridx '.asc'];
    strlabels = [filepath type '_labels_' stridx '.asc'];
    data = textread(strdata);
    labels = textread(strlabels);
end

if (class)
	x = data(labels==class,:);
	y = labels(labels==class,:);
else
	x = data;
	y = labels;
end
