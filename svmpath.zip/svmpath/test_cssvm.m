% Cost Sensitive Support Vector Machine
% CS-SVM solution path demo
% 
% Gyemin Lee, University of Michigan
% 2009.5.17
% 
clear
home
load spine;
% load diabetes;
% load hill
% load breast;
% load ionosphere;
% kenel bandwidth

cs_sigma = 0.5;

mylength=length(yt);
mylength=floor(0.65*mylength*0.8*0.5);
index1=find(yt==1);
index2=find(yt==-1);
index1=index1(1:mylength);
index2=index2(1:mylength);
xt=xt([index1;index2],:);
yt=yt([index1;index2]);
% find CS-SVM solution path over /lambda with fixed \gamma = N_-/N

%[csb_lambda, csb_alpha, csb_elbow] = cssvm_path_lambda_wb(xt,yt,@knl_radial,cs_sigma);

%[csb_lambda2, csb_alpha2, csb_beta2, csb_elbow2] = beta_cssvm_path_lambda_wb(xt,yt,@knl_radial,cs_sigma);

[csb_lambda3, csb_alpha3, csb_beta3, csb_elbow3, csb_new_alpha3] = beta_cssvm_path_lambda_wb2(xt,yt,@knl_radial,cs_sigma);


% plot decision boundaries

% solution path over \lambda
figure(2)
%plot_cssvm(xt, yt, @knl_radial, cs_sigma, csb_lambda, csb_alpha, 0, true, 'pics/spine');
%plot(csb_beta2)

% Plot csb_beta3 with a label
plot(csb_beta3, 'DisplayName', 'Beta');
hold on;

% Plot csb_new_alpha3 with a label
plot(csb_new_alpha3, 'DisplayName', 'New Alpha');

% Adding grid for better readability
grid on;

% Adding legend to distinguish between the plots
legend show;

% Optionally, add labels and a title
xlabel('Index');
ylabel('Value');
title('Comparison of Beta and New Alpha Values');
