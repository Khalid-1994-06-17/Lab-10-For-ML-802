% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% balanced cost sensitive support vector machine solution path
%
% gyemin lee    2007/08/12
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lambda alpha elbow] = ...
	cssvm_path_lambda_wb(x, y, hkernel, kernelparam, btrace)
% function [lambda alpha elbow] = ...
% 	cssvm_path_lambda_wb(x, y, hkernel, kernelparam, btrace)
%	x				N x p feature vector
%	y				N x 1 label
%	hkernel			kernel function handle
%	kernelparam		kernel parameter
%	btrace			boolean trace
%
if nargin < 3, hkernel = @knl_poly; end
if nargin < 4, kernelparam = 1; end
if nargin < 5, btrace = false; end

EPS = 1e-10;
lambdamin = 1e-3;

N = length(y);
Np = sum(y==1);
Nm = sum(y==-1);
gamma = Nm/N;	% balanced svm


Left = (1:N)';
Elbow = [];
Right = [];

nmoves = 5*N;				% maximum number of steps
lambda = zeros(nmoves,1);
alpha = zeros(N,nmoves);
stats = zeros(nmoves,3);
elbow = cell(nmoves,1);

K = hkernel(x, x, kernelparam);
K = (K+K')/2;
Kt = diag(y)*K*diag(y);

k = 1;		% step
[lambda(k) alpha(:,k) Elbow] = svminit(y, Kt, gamma);
Left = setdiff(Left, Elbow);
Kstar = Kt(Elbow, Elbow);
fl = (K*(alpha(:,k).*y)) / lambda(k);

movefrom = repmat(' ', 1, length(Elbow));
moveto = repmat('E', 1, length(Elbow));
obs = Elbow;

stats(k,:) = svmstat(y, fl, Elbow);
elbow{k} = Elbow;

if (btrace)
	strtrace = svmprint(k, obs, movefrom, moveto, lambda(k), stats(k,:));
end

while (lambda(k)>lambdamin)
	if (isempty(Elbow))
		% the elbow is empty. need to reinitialize.
		[lambdat alphat Elbowt] = svminit(y(Left), Kt(Left, Left), gamma);
        if (isempty(lambdat) || lambdat<0)
            break
        end
        if (lambda(k)<lambdat)
            fprintf('lambda(k)<lambdat \n');
            break
        end
		lambda(k+1) = lambdat;
		alpha(:,k+1) = alpha(:,k);
		Elbow = Left(Elbowt);
		Left = setdiff(Left, Elbow);
		
		Kstar = Kt(Elbow, Elbow);
		fl = (K*(alpha(:,k+1).*y)) / lambda(k+1);
% 		fl = lambda(k)/lambda(k+1)*fl;
		
		movefrom = repmat(' ', 1, length(Elbow));
		moveto = repmat('E', 1, length(Elbow));
		obs = Elbow;
    else
% 		Kstar = Kt(Elbow, Elbow);
		b = Kstar\ones(length(Elbow),1); %BETA
		
		hl = K(:,Elbow)*(b.*y(Elbow));
		dl = fl - hl;
		
		% check for immobile margin
		immobile = sum(abs(dl))/N < EPS;
		
		% check for exits from elbow
		temp = ~(abs(b)<EPS);
		lambdaleft = -ones(size(temp));
		lambdaright = -ones(size(temp));
        if sum(temp)
            lambdaleft(temp) = ((y(Elbow(temp))==-1)+y(Elbow(temp))*gamma-alpha(Elbow(temp),k)+lambda(k)*b(temp))./b(temp);
            lambdaright(temp) = (-alpha(Elbow(temp),k)+lambda(k)*b(temp))./b(temp);
        end
		lambdarl = [lambdaright; lambdaleft];
		lambdaexit = max(lambdarl(lambdarl < lambda(k) - EPS));
		if isempty(lambdaexit), lambdaexit = -1; end
% 		if (length(temp)==1 && temp == 0), lambdaexit = -1; 
% 		else
% 		lambdaleft = zeros(size(temp));
% 		lambdaleft(temp) = ((y(Elbow(temp))==-1)+y(Elbow(temp))*gamma-alpha(Elbow(temp),k)+lambda(k)*b(temp))./b(temp);
% 		lambdaleft(~temp) = -1;
% 		lambdaright = zeros(size(temp));
% 		lambdaright(temp) = (-alpha(Elbow(temp),k)+lambda(k)*b(temp))./b(temp);
% 		lambdaright(~temp) = -1;
% 		lambdarl = [lambdaright; lambdaleft];
% 		lambdaexit = max(lambdarl(lambdarl < lambda(k) - EPS));
% 		if isempty(lambdaexit), lambdaexit = -1; end
% 		end
		
		% when immobile, leave
% 		if (immobile && lambdaexit<lambdamin), break, end
		
		% check for entry into elbow
        if (~immobile)
			temp = ~(abs(y-hl)<EPS);
			temp(Elbow) = false;
            temp(obs) = false;
			lambdae = zeros(size(temp));
			lambdae(temp) = lambda(k).*dl(temp)./(y(temp)-hl(temp));
			lambdae(~temp) = -1;
			lambdaentry = max(lambdae(lambdae < lambda(k) - EPS));
% 			lambdaentry = max(lambdae(lambdae < lambda(k)));
			if isempty(lambdaentry), lambdaentry = -1; end
		else
			lambdaentry = -1;
        end
		
		lambdamax = max(lambdaexit, lambdaentry);
		if (lambdamax<0), break, end
		
		% update lambda, alpha
		lambda(k+1) = lambdamax;
        if (lambda(k+1)>lambda(k)), break, end
% 		alpha(:,k+1) = alpha(:,k);
		alpha(Right,k+1) = 0;
		alpha(Left,k+1) = gamma*(y(Left)==1) + (1-gamma)*(y(Left)==-1);
		alpha(Elbow,k+1) = alpha(Elbow,k) - (lambda(k)-lambdamax)*b;
% 		fl = lambda(k) / lambda(k+1) * dl + hl;
		fl = (K*(alpha(:,k+1).*y)) / lambda(k+1);
		
		% update sets
		if (lambdaentry > lambdaexit)
% 			iin = find(lambdae==lambdaentry);
            iin = find(abs(lambdae-lambdaentry)<EPS);
			obs = iin;
			
			tempe = ismember(iin, Left);
			movefrom = repmat('R', 1, length(iin));
			movefrom(tempe) = 'L';
			
			Left = setdiff(Left, iin);
			Right = setdiff(Right, iin);
			
			Elbow = [Elbow; iin];
			Kstar = Kt(Elbow, Elbow);
			moveto = repmat('E', 1, length(iin));
		else
		    tempr = abs(lambdaright - lambdaexit)<EPS;
		    toright = Elbow(tempr);
		    templ = abs(lambdaleft - lambdaexit)<EPS;
		    toleft = Elbow(templ);
		    temp = tempr | templ;
		    
		    Elbow = Elbow(~temp);
		    Right = [Right; toright];
		    moveto = repmat('R', 1, length(toright));
		    Left = [Left; toleft];
		    moveto = [moveto, repmat('L', 1, length(toleft))];
		
 		    Kstar = Kt(Elbow,Elbow);
		    obs = [toright; toleft];
			movefrom = repmat('E', 1, length(moveto));
		end
	end
	
	k = k + 1;
	
	stats(k,:) = svmstat(y, fl, Elbow);
	elbow{k} = Elbow;
	
	if (btrace)
		strtrace = [strtrace, ...
			svmprint(k, obs, movefrom, moveto, lambda(k), stats(k,:))];
	end
end

% outputs
lambda = lambda(1:k);
alpha = alpha(:,1:k);
stats = stats(1:k,:);
elbow = elbow(1:k);

% feasiblity check
if ~isempty(find(alpha < -EPS*2 | alpha > repmat((y==-1)+y*gamma,1,k) + 2*EPS,1));
    fprintf('WARNING: balanced CS-SVM : infeasible solution!!\n');
end

% print the result
if (btrace)
	fresult = fopen('cssvm_lam.txt', 'w');
	fwrite(fresult, strtrace);
	fclose(fresult);
%	strtrace
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lambda alpha Elbow] = svminit(y, Kt, gamma)
%function [lambda alpha Elbow] = svminit(y, Kt, gamma)
%	svm initialization
%
EPS = 1e-10;
alpha = gamma*(y==1) + (1-gamma)*(y==-1);
gk = Kt*alpha;

lambda = max(gk);
Elbow = find(lambda - gk < EPS);
% [lambda Elbow] = max(gk);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function stats = svmstat(y, f, Elbow)
%function stats = svmstat(y, f, Elbow)
%	statistics
%	size of Elbow, number of error points, sum of margin errors
%
yf = y.*f;

stats = zeros(1,3);
stats(1) = length(Elbow);		% size of Elbow
stats(2) = sum(yf<0);			% error
stats(3) = sum(1-yf(yf<1));		% margin


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function str = svmprint(step, obs, movefrom, moveto, lambda, stats)
%function str = svmprint(step, obs, movefrom, moveto, lambda, stats)
%	trace the solution path
%
str = '';
for ii=1:length(obs)
	strtemp = sprintf('%3d: Obs %3d %c->%c lambda=%6.6f  Elbow=%3d  Error=%3d  Margin=%3.2f\n', ...
		step, obs(ii), movefrom(ii), moveto(ii), lambda, stats(1), stats(2), stats(3));
	str = [str, strtemp];
end
