%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function plot_cssvm_set(x, y, hkernel, kernelparam, lambda, alpha, alpha0, pset)
% function plot_cssvm_set(x, y, hkernel, kernelparam, lambda, alpha, alpha0, pset)
%	x				N x p feature vector
%	y				N x 1 label
%	hkernel			kernel function handle
%	kernelparam		kernel parameter
%	lambda			lambda=1/C reaularizaiton parameter
%	alpha			N x M solution paths for M gammas
%	alpha0			solution path - intercept
%	pset			index set of pictures
%
[N M] = size(alpha);

if (length(lambda)<M)
    lambda = lambda*ones(M,1);
end
if (nargin<7 || length(alpha0)<M)
	alpha0 = zeros(M,1);
end
if nargin<8, pset = (1:M)'; end

x = x(:,1:2);

blinear = isequal(hkernel, @knl_poly) && (kernelparam(1) == 1);

if (blinear)	Kgrid = []; X1 = []; X2 = [];
else			[Kgrid X1 X2]= util_knlgrid(x, hkernel, kernelparam);
end

colorset = {'k', 'm', 'g', 'c'};
coloridx = 0;
% lnstyle = {':', '--'};
lnstyle = {':', '--', '-', '-.', '--'};
lnsidx = 0;
lnwidth = [3 3 3 3 2];
lnwidx = 0;

plot_init();
for l=1:length(pset)
    idx = pset(l);

	fhat = plot_cssvm_fgrid(x, y, Kgrid, lambda(idx), alpha(:,idx), alpha0(idx), blinear);
	
	hold on
    handle = plot_cssvm_step(x, y, X1, X2, fhat, false, false);
	coloridx = mod(coloridx+1,length(colorset)); if coloridx==0, coloridx = length(colorset); end
	lnsidx = mod(lnsidx+1,length(lnstyle)); if lnsidx==0, lnsidx = length(lnstyle); end
	lnwidx = mod(lnwidx+1,length(lnwidth)); if lnwidx==0, lnwidx = length(lnwidth); end
% 	set(handle, 'Color', colorset{coloridx});
% 	set(handle, 'TextList',gamma(idx));
    set(handle, 'LineStyle', lnstyle{lnsidx});
    set(handle, 'LineWidth', lnwidth(lnwidx));
    if l==1, set(handle, 'Fill', 'on'); end
	hold off
end
