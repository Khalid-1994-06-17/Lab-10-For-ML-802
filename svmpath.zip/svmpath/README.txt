Matlab code for the algorithm of the following papers

G.Lee and C.Scott, "Nested support vector machines"
G.Lee and C.Scott, "The one class support vector machine solution path"

Author : Gyemin Lee
Date : May, 2009.

This software is intended for noncommercial purposes.

----------------------------------------

--Demo
run 'test_ocsvm.m' and 'test_cssvm.m' 


--Files

test_ocsvm.m : demo for OC-SVM
test_cssvm.m : demo for CS-SVM
banana_1.mat : banana dataset for demo

ocsvm_path.m : OC-SVM solution path algorithm over \lambda
cssvm_path_lambda_wb.m : CS-SVM solution path algorithm over \lambda with a fixed \gamma
cssvm_path_gamma_wb.m : CS-SVM solution path algorithm over \gamma with a fixed \lambda
cssvm_path_gamma_init.m : helper function for 'cssvm_path_gamma_wb.m'

cssvm_path_lambda.m : CS-SVM solution path algorithm (with intercept) over \lambda with a fixed \gamma
cssvm_path_gamma.m : CS-SVM solution path algorithm (with intercept) over \gamma with a fixed \lambda


knl_radial.m : radial basis kernel function
knl_normal.m : normalized gaussian kernel function 


util_*.m : helper functions
plot_*.m : functions for drawing decision boundaries of nested SVMs.

