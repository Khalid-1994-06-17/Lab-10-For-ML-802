%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% balanced cost sensitive support vector machine solution path
%
% gyemin lee    2007/08/12
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lambda alpha alpha0 elbow] = ...
	cssvm_path_lambda(x, y, hkernel, kernelparam, btrace)
% function [lambda alpha elbow] = ...
%		cssvm_path_lambda(x, hkernel, kernelparam, btrace)
%	x				N x p feature vector
%	y				N x 1 label
%	hkernel			kernel function handle
%	kernelparam		kernel parameter
%	btrace			boolean trace
%
if nargin < 3, hkernel = @knl_poly; end
if nargin < 4, kernelparam = 1; end
if nargin < 5, btrace = true; end

eps = 1e-10;
lambdamin = 1e-4;

N = length(y);
Np = sum(y==1);
Nm = sum(y==-1);
gamma = Nm/N;	% balanced svm

Left = (1:N)';
Elbow = [];
Right = [];

nmoves = 5*N;				% maximum number of steps
lambda = zeros(nmoves,1);
alpha = zeros(N,nmoves);
alpha0 = zeros(nmoves, 1);
stats = zeros(nmoves,3);
elbow = cell(nmoves,1);

K = hkernel(x, x, kernelparam);
Kt = diag(y)*K*diag(y);

k = 1;		% step
[lambda(k) alpha(:,k) alpha0(k) Elbow] = bcssvminit(y, K, gamma);
Left = setdiff(Left, Elbow);
Kstar = [0 y(Elbow)'; y(Elbow) Kt(Elbow, Elbow)];
fl = (K*(alpha(:,k).*y) + alpha0(k)) / lambda(k);

movefrom = repmat(' ', 1, length(Elbow));
moveto = repmat('E', 1, length(Elbow));
obs = Elbow;

stats(k,:) = bcssvmstat(y, fl, Elbow);
elbow{k} = Elbow;

if (btrace)
	strtrace = bcssvmprint(k, obs, movefrom, moveto, lambda(k), stats(k,:));
end

while (k<nmoves && lambda(k)>lambdamin)
	if (isempty(Elbow))
		% the elbow is empty. need to reinitialize.
		[lambdat alphat alpha0t Elbowt] = bcssvminit(y(Left), K(Left, Left), gamma);
		lambda(k+1) = lambdat;
		alpha(:,k+1) = alpha(:,k);
		alpha0(k+1) = alpha0t;
		Elbow = Left(Elbowt);
		Left = setdiff(Left, Elbow);
		
		Kstar = [0 y(Elbow)'; y(Elbow) Kt(Elbow, Elbow)];
% 		fl = (K*(alpha(:,k+1).*y) + alpha0(k+1)) / lambda(k+1);
		fl = lambda(k)/lambda(k+1)*(fl+(alpha0(k+1)-alpha0(k))/lambda(k));
		
		movefrom = repmat(' ', 1, length(Elbow));
		moveto = repmat('E', 1, length(Elbow));
		obs = Elbow;
	else
% 		Kstar = [0 y(Elbow)'; y(Elbow) Kt(Elbow, Elbow)];
		bstar = Kstar\([0; ones(length(Elbow),1)]);
		b0 = bstar(1);
		b = bstar(2:end);
		
		hl = K(:,Elbow)*(b.*y(Elbow)) + b0;
		dl = fl - hl;
		
		% check for immobile margin
		immobile = sum(abs(dl))/N < eps;
		
		% check for exits from elbow
		temp = ~(abs(b)<eps);
		if (length(temp)==1 && temp == 0), lambdaexit = -1; 
		else
		lambdaleft = zeros(size(temp));
		lambdaleft(temp) = ((y(Elbow(temp))==-1)+y(Elbow(temp))*gamma-alpha(Elbow(temp),k)+lambda(k)*b(temp))./b(temp);
		lambdaleft(~temp) = -1;
		lambdaright = zeros(size(temp));
		lambdaright(temp) = (-alpha(Elbow(temp),k)+lambda(k)*b(temp))./b(temp);
		lambdaright(~temp) = -1;
		lambdarl = [lambdaright; lambdaleft];
		lambdaexit = max(lambdarl(lambdarl < lambda(k) - eps));
		if isempty(lambdaexit), lambdaexit = -1; end
		end
		
		% when immobile, leave
		if (immobile && lambdaexit<lambdamin), break, end
		
		% check for entry into elbow
		if (~immobile)
			temp = ~(abs(y-hl)<eps);
			temp(Elbow) = false;
			lambdae = zeros(size(temp));
			lambdae(temp) = lambda(k).*dl(temp)./(y(temp)-hl(temp));
			lambdae(~temp) = -1;
			lambdaentry = max(lambdae(lambdae < lambda(k) - eps));
% 			lambdaentry = max(lambdae(lambdae < lambda(k)));
			if isempty(lambdaentry), lambdaentry = -1; end
		else
			lambdaentry = -1;
		end
		
		lambdamax = max(lambdaexit, lambdaentry);
		if (lambdamax<lambdamin), break, end
		
		% update lambda, alpha
		lambda(k+1) = lambdamax;
% 		alpha(:,k+1) = alpha(:,k);
		alpha(Right,k+1) = 0;
		alpha(Left,k+1) = gamma*(y(Left)==1) + (1-gamma)*(y(Left)==-1);
		alpha(Elbow,k+1) = alpha(Elbow,k) - (lambda(k)-lambdamax)*b;
		alpha0(k+1) = alpha0(k) - (lambda(k)-lambdamax)*b0;
		fl = lambda(k) / lambda(k+1) * dl + hl;
		
		% update sets
		if (lambdaentry > lambdaexit)
			iin = find(lambdae==lambdaentry);
			obs = iin;
			
			tempe = ismember(iin, Left);
			movefrom = repmat('R', 1, length(iin));
			movefrom(tempe) = 'L';
			
			Left = setdiff(Left, iin);
			Right = setdiff(Right, iin);
			
			Elbow = [Elbow; iin];
% 			Kstar = K(Elbow, Elbow);
			Kstar = [0 y(Elbow)'; y(Elbow) Kt(Elbow, Elbow)];
			moveto = repmat('E', 1, length(iin));
		else
		    movefrom = 'E';
		    
		    tempr = abs(lambdaright - lambdaexit)<eps;
		    toright = Elbow(tempr);
		    templ = abs(lambdaleft - lambdaexit)<eps;
		    toleft = Elbow(templ);
		    temp = tempr | templ;
		    
		    Elbow = Elbow(~temp);
		    Right = [Right; toright];
		    moveto = repmat('R', 1, length(toright));
		    Left = [Left; toleft];
		    moveto = [moveto, repmat('L', 1, length(toleft))];
		
% 		    Kstar = Kt(Elbow,Elbow);
			Kstar = [0 y(Elbow)'; y(Elbow) Kt(Elbow, Elbow)];
		    obs = [toright; toleft];
			movefrom = repmat('E', 1, length(moveto));
		end
	end
	
	k = k + 1;
	
	stats(k,:) = bcssvmstat(y, fl, Elbow);
	elbow{k} = Elbow;
	
	if (btrace)
		strtrace = [strtrace, ...
			bcssvmprint(k, obs, movefrom, moveto, lambda(k), stats(k,:))];
	end
end

% outputs
lambda = lambda(1:k);
alpha = alpha(:,1:k);
alpha0 = alpha0(1:k);
stats = stats(1:k,:);
elbow = elbow(1:k);

% print the result
if (btrace)
	fresult = fopen('path.txt', 'w');
	fwrite(fresult, strtrace);
	fclose(fresult);
%	strtrace
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lambda alpha alpha0 Elbow] = bcssvminit(y, K, gamma)
%function [lambda alpha alpha0 Elbow] = bcssvminit(y, K, gamma)
%	svm initialization
%
alpha = gamma*(y==1) + (1-gamma)*(y==-1);
gk = K*(alpha.*y);

[gplus idx] = max(gk(y==1));
Iplus = find(y==1);
iplus = Iplus(idx);

[gminus idx] = min(gk(y==-1));
Iminus = find(y==-1);
iminus = Iminus(idx);

lambda = (gplus-gminus)/2;
alpha0 = -(gplus+gminus)/2;
Elbow = [iplus; iminus];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function stats = bcssvmstat(y, f, Elbow)
%function stats = bcssvmstat(y, f, Elbow)
%	statistics
%	size of Elbow, number of error points, sum of margin errors
%
eps = 1e-10;

yf = y.*f;

stats = zeros(1,3);
stats(1) = length(Elbow);		% size of Elbow
stats(2) = sum(yf<0);			% error
stats(3) = sum(1-yf(yf<1));		% margin


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function str = bcssvmprint(step, obs, movefrom, moveto, lambda, stats)
%function str = bcssvmprint(step, obs, movefrom, moveto, lambda, stats)
%	trace the solution path
%
str = '';
for ii=1:length(obs)
	strtemp = sprintf('%3d: Obs %3d %c->%c lambda=%6.6f  Elbow=%3d  Error=%3d  Margin=%3.2f\n', ...
		step, obs(ii), movefrom(ii), moveto(ii), lambda, stats(1), stats(2), stats(3));
	str = [str, strtemp];
end
