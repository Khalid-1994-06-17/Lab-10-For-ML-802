% One Class Support Vector Machine
% OC-SVM solution path demo
% 
% Gyemin Lee, University of Michigan
% 2009.5.17
% 
clear
home

datastr = 'spine';
dataidx = '1';

% training data set
xt = util_rdbenchdata(datastr, dataidx, 'train', -1);

% kenel bandwidth
oc_sigma = 0.5;

% find OC-SVM solution path over \lambda
[oc_lambda, oc_alpha] = ocsvm_path(xt, @knl_radial, oc_sigma);

% plot decision boundaries
figure(2)
plot_ocsvm(xt, @knl_radial, oc_sigma, oc_lambda, oc_alpha);

